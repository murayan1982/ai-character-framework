@echo off
setlocal

cd /d "%~dp0"

echo ==============================
echo AI Conversation Framework
echo ==============================
echo.

venv\Scripts\python.exe main.py

echo.
echo Program ended.
pause
endlocal